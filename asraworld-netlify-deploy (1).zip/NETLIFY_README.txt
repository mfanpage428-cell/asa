ASRAWORLD — Netlify deploy

Bu loyiha Vite + React.
Netlify avtomatik ravishda:
- npm run build
- dist/ papkasini publish qiladi
- SPA route'larini index.html ga yo'naltiradi.

Agar GitHub orqali deploy qilsangiz, repository rootini ulang.
Build command: npm run build
Publish directory: dist
